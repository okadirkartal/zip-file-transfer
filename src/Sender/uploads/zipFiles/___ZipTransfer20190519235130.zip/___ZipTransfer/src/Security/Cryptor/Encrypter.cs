using System;
using System.IO;
using System.Security.Cryptography;
using Cryptor.Contracts;
using Microsoft.Extensions.Configuration;

namespace Cryptor
{
    public class Encrypter  : BaseCryptor,IEncrypter
    {
        private const CipherMode CipherMode = System.Security.Cryptography.CipherMode.ECB;
        
        public Encrypter(IConfiguration configuration):base(configuration)  {}
 
        public string Encrypt(string data)
        {
            if (string.IsNullOrEmpty(data)) return string.Empty;
           
            using (Aes aes = Aes.Create())
            {
                aes.Key = _cryptoKey;
                aes.Mode = CipherMode;
                aes.BlockSize = 128;
                aes.Padding = Padding;

                aes.GenerateIV();
               
                byte[] encrypted;
                
                using (var memoryStream = new MemoryStream())
                {
                    using (var cryptoStream = new CryptoStream(memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (var streamWriter = new StreamWriter(cryptoStream))
                        {
                            streamWriter.Write(data);
                        }
                        encrypted = memoryStream.ToArray();
                    }
                }

                var combinedIVCT = new byte[aes.IV.Length + encrypted.Length];
               
                Array.Copy(aes.IV, 0, combinedIVCT, 0, aes.IV.Length);
                
                Array.Copy(encrypted, 0, combinedIVCT, aes.IV.Length, encrypted.Length);
                
                return  Convert.ToBase64String(combinedIVCT);
            }
        } 
    }
}