using System.Collections.Generic;
using System.Threading.Tasks;
using Authenticator.Entities;

namespace Authenticator.Services.Contracts
{
    public interface IUserService
    {
        Task<User> Authenticate(string username, string password);
       
        Task<IEnumerable<User>> GetAll();
    }
}