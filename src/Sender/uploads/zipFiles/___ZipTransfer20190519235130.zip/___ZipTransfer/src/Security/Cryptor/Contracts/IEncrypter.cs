namespace Cryptor.Contracts
{
    public interface IEncrypter
    {
        string Encrypt(string data); 
    }
}