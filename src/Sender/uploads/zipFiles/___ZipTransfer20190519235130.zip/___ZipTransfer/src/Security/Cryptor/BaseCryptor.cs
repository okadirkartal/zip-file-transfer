using System.Security.Cryptography;
using  System.Text;
using Microsoft.Extensions.Configuration;

namespace Cryptor
{
    public class BaseCryptor
    {
        protected readonly byte[] _cryptoKey;
        
        protected const PaddingMode Padding = PaddingMode.PKCS7;

        protected BaseCryptor(IConfiguration configuration)
        {
            _cryptoKey = Encoding.UTF8.GetBytes(configuration[Common.Constants.CryptoKey]?? "37181KA07RT372AL"); 
        }
    }
}