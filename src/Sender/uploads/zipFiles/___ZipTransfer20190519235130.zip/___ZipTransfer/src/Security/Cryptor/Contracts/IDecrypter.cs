namespace Cryptor.Contracts
{
    public interface IDecrypter
    {
        string Decrypt(string data);
    }
}