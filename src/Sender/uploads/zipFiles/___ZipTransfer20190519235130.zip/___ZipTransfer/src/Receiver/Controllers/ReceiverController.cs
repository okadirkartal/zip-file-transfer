﻿using Microsoft.AspNetCore.Mvc;

namespace Receiver.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReceiverController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult PostFileDataWithCredentials([FromBody] string jsonData)
        {
            if (string.IsNullOrEmpty(jsonData)) return NoContent();

            return Ok();
        }
        
    }
}