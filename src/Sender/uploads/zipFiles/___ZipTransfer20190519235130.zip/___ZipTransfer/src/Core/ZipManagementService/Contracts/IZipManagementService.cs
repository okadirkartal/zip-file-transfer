using Cryptor.Contracts;

namespace ZipManagementService.Contracts
{
    public interface IZipManagementService
    {
        string GetSerializedDirectoryStructure(string savedZipFilePath);
    }
}