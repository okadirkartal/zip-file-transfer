namespace Entities
{
    public class TransferModel  : UserModel
    {
        public string JsonData { get; set; }
    }
}