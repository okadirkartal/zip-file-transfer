using System.IO;
using System.IO.Compression;
using System.Linq;
using Cryptor.Contracts;
using Microsoft.Extensions.Configuration; 
using Newtonsoft.Json;
using ZipManagementService.Contracts;

namespace ZipManagementService
{
    public class ZipManagementService : IZipManagementService
    {
        private readonly IEncrypter _encrypter;

        private readonly IConfiguration _configuration;

        public ZipManagementService(IConfiguration configuration,
            IEncrypter encrypter)
        {
            this._configuration = configuration;
            this._encrypter = encrypter; 
        }

        public string GetSerializedDirectoryStructure(string savedZipFilePath)
        {
            using (ZipArchive zipFile = ZipFile.OpenRead(savedZipFilePath))
            {
                string saveablePath =Path.Combine(_configuration[Common.Constants.UploadPathForZipFiles],Path.GetFileNameWithoutExtension(savedZipFilePath));

                zipFile.ExtractToDirectory(saveablePath,true);

                var result = DirectoryModel.CreateStructureFromDirectoryNode(saveablePath);
              
                return JsonConvert.SerializeObject(result);
            }
        }
              
         
    }
}