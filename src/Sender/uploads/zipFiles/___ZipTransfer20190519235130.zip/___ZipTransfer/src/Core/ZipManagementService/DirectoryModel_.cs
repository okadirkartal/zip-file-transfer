using System.Collections.Generic;
using Newtonsoft.Json;

namespace ZipManagementService
{
    [JsonObject]
    public class DirectoryModel_
    {                         
//        [JsonProperty]
//        public Dictionary<string, DirectoryModel> Folders { get; set; }
//
//        [JsonProperty]
//        public List<string> Files { get; set; }
//
//        
//        public DirectoryModel()
//        {
//            Folders = new Dictionary<string, DirectoryModel>();
//            Files = new List<string>();
//        }
//
//        public DirectoryModel Add(string path, bool isFile = true)
//        {
//            int index = path.IndexOf('/');
//           
//            if (index > -1)
//            {
//                DirectoryModel folder = Add(path.Substring(0, index), false);
//               
//                return folder.Add(path.Substring(index + 1), true);
//            }
//
//            if (path == "") return this;
//
//        
//            if (isFile && path != "." && path.Contains("."))
//            {
//                Files.Add(path);
//                
//                return this;
//            }
//
//            DirectoryModel child;
//           
//            if (Folders.ContainsKey(path))
//            {
//                child = Folders[path];
//            }
//            else
//            {
//                child = new DirectoryModel();
//               
//                Folders.Add(path, child);
//            }
//            return child;
//        }
//        
    }
}