﻿using System;

namespace Common
{
    public class Constants
    {
        public const string ReceiverApiBaseUrl = "ReceiverApi:BaseUrl";

        public const string SecurityHeader = "SecurityHeader:Header";

        public const string CryptoKey = "Security:CryptoKey";

        public const string UploadPathForZipFiles = "UploadPaths:ZipPath";

        public const string ExtractedZipPath = "UploadPaths:ExtractedZipPath";
    }
}