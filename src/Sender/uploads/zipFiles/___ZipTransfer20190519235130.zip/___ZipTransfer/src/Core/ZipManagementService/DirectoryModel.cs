using System.Collections.Generic;
using System.IO;
using Cryptor.Contracts;

using System.Linq;
namespace ZipManagementService
{
    public class DirectoryModel
    {
        public string itemName { get; set; }
       
        public List<DirectoryModel> subItems { get; set; }

        public DirectoryModel(string itemName) {
            this.itemName = itemName;
           
            subItems = new List<DirectoryModel>();
        }
        
        public static DirectoryModel CreateDirectoryNode(DirectoryInfo directoryInfo) {
            var node = new DirectoryModel(directoryInfo.Name);
         
            foreach (var directory in directoryInfo.GetDirectories()) {
                node.subItems.Add(CreateDirectoryNode(directory));
            }
            
            foreach (var file in directoryInfo.GetFiles()) {
                node.subItems.Add(new DirectoryModel(file.Name));
            }
            return node;
        }

        public static DirectoryModel CreateStructureFromDirectoryNode(string fileName) {
            var rootDirectoryInfo = new DirectoryInfo(fileName);
            
            DirectoryModel root = new DirectoryModel(fileName);
            root.subItems.Add(CreateDirectoryNode(rootDirectoryInfo));
            return root;
        }
    }
}