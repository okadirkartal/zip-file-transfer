﻿using System.Threading.Tasks;

namespace Network.Contracts
{
    public interface IHttpClientWrapper
    {
        string BaseUrl { get; set; }
        
        Task<TModel> GetAsync<TModel>(string endpoint);

        Task<TDto> PostAsync<TDto>(string endpoint, TDto dto);

        void AddHeader(string key, string value);
    }
}