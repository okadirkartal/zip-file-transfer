using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Network.Contracts
{
    public class HttpClientWrapper : IHttpClientWrapper
    {
        private HttpClient _client;

        public string BaseUrl { get; set; }

        public HttpClientWrapper()
        {
            _client.BaseAddress = new Uri(BaseUrl);

            _client.DefaultRequestHeaders.Accept.Clear();

            _client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }


        public async Task<TModel> GetAsync<TModel>(string endpoint)
        {
            _client = GetHttpClient(endpoint);

            var response = await _client.GetAsync(endpoint);

            var result = await response.Content.ReadAsStringAsync();

            _client.Dispose();

            return JsonConvert.DeserializeObject<TModel>(result);
        }

        public async Task<TDto> PostAsync<TDto>(string endpoint, TDto dto)
        {
            return await PostAsync<TDto, TDto>(endpoint, dto);
        }

        private async Task<TResponseDto> PostAsync<TRequestDto, TResponseDto>(string endpoint, TRequestDto dto)
        {
            if (string.IsNullOrEmpty(endpoint)) throw new ArgumentNullException(nameof(endpoint));

            if (dto == null) throw new ArgumentNullException(nameof(dto));


            string content = JsonConvert.SerializeObject(dto);

            HttpContent httpContent = new StringContent(content, Encoding.UTF8, "application/json");

            _client = GetHttpClient(endpoint);

            HttpResponseMessage responseMessage = await _client.PostAsync(endpoint, httpContent);

            _client.Dispose();

            var data = await responseMessage.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<TResponseDto>(data);
        }

        public void AddHeader(string name, string value)
        {
            if(!_client.DefaultRequestHeaders.Contains(name))
            _client.DefaultRequestHeaders.Add(name,value);
        }


        private HttpClient GetHttpClient(string endpoint)
        {
            _client = new HttpClient();
            _client.BaseAddress = new Uri(endpoint);
            _client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            return _client;
        }
    }
}