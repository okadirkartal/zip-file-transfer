namespace Sender.Models
{
    public class JsonItem
    {
        public JsonItem()
        {
            
        }

        public JsonTree Children { get; }
    }
}