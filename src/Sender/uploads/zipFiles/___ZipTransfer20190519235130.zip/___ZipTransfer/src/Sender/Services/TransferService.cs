using System;
using System.Threading;
using System.Threading.Tasks;
using Common;
using Entities;
using Microsoft.Extensions.Configuration;
using Network.Contracts;
using Sender.Services.Contracts;

namespace Sender.Services
{
    public class TransferService : ITransferService
    {
        private readonly IHttpClientWrapper _httpClient;

        private readonly IConfiguration _configuration;

        public TransferService(IHttpClientWrapper httpClient, IConfiguration configuration)
        {
            this._httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
          
            this._configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            
            httpClient.BaseUrl = this._configuration[Constants.ReceiverApiBaseUrl];
        }

        public async Task<bool> PostToReceiverAsync(string endPoint, TransferModel model)
        {
            await Task.Delay(1000);
            CancellationToken.None.ThrowIfCancellationRequested();

            
            this._httpClient.AddHeader(this._configuration[Constants.SecurityHeader],
                $"{model.UserName} {model.Password}");
            
            var response = await _httpClient.PostAsync(endPoint, model.JsonData);
            
            return response.Equals("OK");
        }
    }
}