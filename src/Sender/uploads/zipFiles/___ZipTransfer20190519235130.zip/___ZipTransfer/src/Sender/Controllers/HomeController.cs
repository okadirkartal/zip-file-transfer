﻿using System.Threading.Tasks;
using Cryptor.Contracts;
using Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Sender.Models;
using Sender.Services.Contracts;
using ZipManagementService.Contracts;

namespace Sender.Controllers
{
    public class HomeController : Controller
    {
        private readonly IFileManagementService _fileManagementService;

        private readonly IZipManagementService _zipManagementService;

        private readonly IEncrypter _encrypter;

        private readonly ITransferService _transferService;

        public HomeController(IFileManagementService fileManagementService,IZipManagementService zipManagementService,
            IEncrypter encrypter,ITransferService transferService)
        {
            
            this._encrypter = encrypter; 
            this._fileManagementService = fileManagementService;
            this._zipManagementService = zipManagementService;
            this._transferService = transferService;
        }
        
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task Index(UploadViewModel model)
        {
            if (ModelState.IsValid)
            {
                var savedResult = await _fileManagementService.SaveZipFileToLocalFolder(model.File);
                
                if (savedResult.result)
                {
                     var result = _zipManagementService.GetSerializedDirectoryStructure(savedResult.savedFilePath);

                    var encryptedData = _encrypter.Encrypt(result);

                    var response = _transferService.PostToReceiverAsync("/Receiver/PostFileDataWithCredentials",
                        new TransferModel()
                        {
                            UserName = _encrypter.Encrypt(model.UserName),Password = _encrypter.Encrypt(model.Password),
                            JsonData = encryptedData
                                
                        });
                }
            } 
        }  
    }
}