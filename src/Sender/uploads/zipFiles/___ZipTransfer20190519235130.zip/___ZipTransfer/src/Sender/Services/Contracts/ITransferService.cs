using System.Threading.Tasks;
using Entities;

namespace Sender.Services.Contracts
{
    public interface ITransferService
    {
        Task<bool> PostToReceiverAsync(string endPoint, TransferModel model);
    }
}