using System.Collections.Generic;
using Newtonsoft.Json;

namespace Sender.Models
{
    public class JsonTree : Dictionary<string,JsonItem>
    {
        private string Type { get; set; }

        private string Name { get; set; }
      
        [JsonIgnore] 
        private string EntryName { get; set; }

        private List<JsonTree> Children { get; }

        
        public JsonTree(string entryName, string name, string type)
        {
            EntryName = entryName;
            Name = name;
            Type = type;
            Children    = new List<JsonTree>();
        }

        public void AddChildren(JsonTree treeItem)
        {
            Children.Add(treeItem);
        }

        public bool ShouldSerializeChildren()
        {
            return Children.Count > 0;
        }
    }
}