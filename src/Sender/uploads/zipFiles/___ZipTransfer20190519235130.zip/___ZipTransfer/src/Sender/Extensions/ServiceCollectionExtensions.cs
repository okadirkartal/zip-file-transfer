using Cryptor;
using Cryptor.Contracts;
using Microsoft.Extensions.DependencyInjection;
using Network.Contracts;
using Sender.Services;
using Sender.Services.Contracts;
using ZipManagement=ZipManagementService;

namespace Sender.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddTransient<IEncrypter, Encrypter>();
            services.AddTransient<IDecrypter, Decrypter>();
            services.AddTransient<ITransferService,TransferService>();
            services.AddTransient<IFileManagementService, FileManagementService>();
            services.AddTransient<ZipManagement.Contracts.IZipManagementService, ZipManagement.ZipManagementService>();
            services.AddSingleton<IHttpClientWrapper, HttpClientWrapper>();
        }

    }
}